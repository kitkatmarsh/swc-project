import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { canActivate, redirectUnauthorizedTo, redirectLoggedInTo } from '@angular/fire/auth-guard';

// Send unauthorized users to login
const redirectUnauthorizedToLogin = () =>
  redirectUnauthorizedTo(['/']);
 
// Automatically log in users
const redirectLoggedInToChat = () => redirectLoggedInTo(['/chat']);

const routes: Routes = [
  {
    path: '',
    redirectTo: 'welcome',
    pathMatch: 'full'
  },
  {
    path: 'login',
    loadChildren: () => import('./pages/login/login.module').then( m => m.LoginPageModule),
    ...canActivate(redirectLoggedInToChat)
  },
  {
    path: 'chat',
    loadChildren: () => import('./pages/chat/chat.module').then( m => m.ChatPageModule),
    ...canActivate(redirectUnauthorizedToLogin)
  },
  {
    path: 'welcome',
    loadChildren: () => import('./welcome/welcome.module').then( m => m.WelcomePageModule)
  },
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: 'register',
    loadChildren: () => import('./register/register.module').then( m => m.RegisterPageModule)
  },
  {
    path: 'standard',
    loadChildren: () => import('./standard/standard.module').then( m => m.StandardPageModule)
  },
  {
    path: 'option1',
    loadChildren: () => import('./option1/option1.module').then( m => m.Option1PageModule)
  },
  {
    path: 'option2',
    loadChildren: () => import('./option2/option2.module').then( m => m.Option2PageModule)
  },
  {
    path: 'option3',
    loadChildren: () => import('./option3/option3.module').then( m => m.Option3PageModule)
  },
  {
    path: 'note1',
    loadChildren: () => import('./note1/note1.module').then( m => m.Note1PageModule)
  },
  {
    path: 'quiz1',
    loadChildren: () => import('./quiz1/quiz1.module').then( m => m.Quiz1PageModule)
  },
  {
    path: 'note2',
    loadChildren: () => import('./note2/note2.module').then( m => m.Note2PageModule)
  },
  {
    path: 'quiz2',
    loadChildren: () => import('./quiz2/quiz2.module').then( m => m.Quiz2PageModule)
  },
  {
    path: 'note3',
    loadChildren: () => import('./note3/note3.module').then( m => m.Note3PageModule)
  },
  {
    path: 'quiz3',
    loadChildren: () => import('./quiz3/quiz3.module').then( m => m.Quiz3PageModule)
  },
  {
    path: 'feedback',
    loadChildren: () => import('./feedback/feedback.module').then( m => m.FeedbackPageModule)
  },
  {
    path: 'view-post',
    loadChildren: () => import('./view-post/view-post.module').then( m => m.ViewPostPageModule)
  },
  {
    path: 'edit-post/:id',
    loadChildren: () => import('./edit-post/edit-post.module').then( m => m.EditPostPageModule)
  },
  {
    path: 'video',
    loadChildren: () => import('./video/video.module').then( m => m.VideoPageModule)
  },
  {
    path: 'about',
    loadChildren: () => import('./about/about.module').then( m => m.AboutPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
