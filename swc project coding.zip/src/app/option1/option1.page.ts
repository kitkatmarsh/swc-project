import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-option1',
  templateUrl: './option1.page.html',
  styleUrls: ['./option1.page.scss'],
})
export class Option1Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
