import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Qc21PageRoutingModule } from './qc21-routing.module';

import { Qc21Page } from './qc21.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Qc21PageRoutingModule
  ],
  declarations: [Qc21Page]
})
export class Qc21PageModule {}
