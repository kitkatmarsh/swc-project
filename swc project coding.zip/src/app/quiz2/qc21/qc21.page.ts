import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qc21',
  templateUrl: './qc21.page.html',
  styleUrls: ['./qc21.page.scss'],
})
export class Qc21Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
