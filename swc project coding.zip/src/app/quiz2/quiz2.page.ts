import { Component, OnInit } from '@angular/core';
import { Data5Service } from "../services/data5.service";

@Component({
  selector: 'app-quiz2',
  templateUrl: './quiz2.page.html',
  styleUrls: ['./quiz2.page.scss'],
})
export class Quiz2Page implements OnInit {
  public searchTerm: String =""
  public items: any;
  constructor(
    private ds: Data5Service
  ) { }

  ngOnInit() {this.filteredItems();
  }

  filteredItems(){
    this.items = this.ds.filterItems(this.searchTerm);
  }

} 


