import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qc26',
  templateUrl: './qc26.page.html',
  styleUrls: ['./qc26.page.scss'],
})
export class Qc26Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
