import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Qc26PageRoutingModule } from './qc26-routing.module';

import { Qc26Page } from './qc26.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Qc26PageRoutingModule
  ],
  declarations: [Qc26Page]
})
export class Qc26PageModule {}
