import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Qc23PageRoutingModule } from './qc23-routing.module';

import { Qc23Page } from './qc23.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Qc23PageRoutingModule
  ],
  declarations: [Qc23Page]
})
export class Qc23PageModule {}
