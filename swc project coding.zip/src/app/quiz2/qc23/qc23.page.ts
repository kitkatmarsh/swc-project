import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qc23',
  templateUrl: './qc23.page.html',
  styleUrls: ['./qc23.page.scss'],
})
export class Qc23Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
