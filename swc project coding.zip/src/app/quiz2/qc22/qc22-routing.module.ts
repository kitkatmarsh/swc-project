import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Qc22Page } from './qc22.page';

const routes: Routes = [
  {
    path: '',
    component: Qc22Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Qc22PageRoutingModule {}
