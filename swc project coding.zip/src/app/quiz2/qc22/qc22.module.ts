import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Qc22PageRoutingModule } from './qc22-routing.module';

import { Qc22Page } from './qc22.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Qc22PageRoutingModule
  ],
  declarations: [Qc22Page]
})
export class Qc22PageModule {}
