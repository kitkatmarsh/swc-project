import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qc22',
  templateUrl: './qc22.page.html',
  styleUrls: ['./qc22.page.scss'],
})
export class Qc22Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
