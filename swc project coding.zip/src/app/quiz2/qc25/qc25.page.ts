import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qc25',
  templateUrl: './qc25.page.html',
  styleUrls: ['./qc25.page.scss'],
})
export class Qc25Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
