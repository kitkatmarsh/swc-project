import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Qc25Page } from './qc25.page';

const routes: Routes = [
  {
    path: '',
    component: Qc25Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Qc25PageRoutingModule {}
