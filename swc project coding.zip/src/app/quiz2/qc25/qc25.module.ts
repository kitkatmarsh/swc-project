import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Qc25PageRoutingModule } from './qc25-routing.module';

import { Qc25Page } from './qc25.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Qc25PageRoutingModule
  ],
  declarations: [Qc25Page]
})
export class Qc25PageModule {}
