import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Quiz2Page } from './quiz2.page';

const routes: Routes = [
  {
    path: '',
    component: Quiz2Page
  },
  {
    path: 'qc21',
    loadChildren: () => import('./qc21/qc21.module').then( m => m.Qc21PageModule)
  },
  {
    path: 'qc22',
    loadChildren: () => import('./qc22/qc22.module').then( m => m.Qc22PageModule)
  },
  {
    path: 'qc23',
    loadChildren: () => import('./qc23/qc23.module').then( m => m.Qc23PageModule)
  },
  {
    path: 'qc24',
    loadChildren: () => import('./qc24/qc24.module').then( m => m.Qc24PageModule)
  },
  {
    path: 'qc25',
    loadChildren: () => import('./qc25/qc25.module').then( m => m.Qc25PageModule)
  },
  {
    path: 'qc26',
    loadChildren: () => import('./qc26/qc26.module').then( m => m.Qc26PageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Quiz2PageRoutingModule {}
