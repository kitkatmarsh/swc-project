import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Qc24Page } from './qc24.page';

const routes: Routes = [
  {
    path: '',
    component: Qc24Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Qc24PageRoutingModule {}
