import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qc24',
  templateUrl: './qc24.page.html',
  styleUrls: ['./qc24.page.scss'],
})
export class Qc24Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
