import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-option3',
  templateUrl: './option3.page.html',
  styleUrls: ['./option3.page.scss'],
})
export class Option3Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
