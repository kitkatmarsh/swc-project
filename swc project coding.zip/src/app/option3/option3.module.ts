import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Option3PageRoutingModule } from './option3-routing.module';

import { Option3Page } from './option3.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Option3PageRoutingModule
  ],
  declarations: [Option3Page]
})
export class Option3PageModule {}
