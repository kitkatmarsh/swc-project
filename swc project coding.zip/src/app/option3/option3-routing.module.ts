import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Option3Page } from './option3.page';

const routes: Routes = [
  {
    path: '',
    component: Option3Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Option3PageRoutingModule {}
