import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc19',
  templateUrl: './nc19.page.html',
  styleUrls: ['./nc19.page.scss'],
})
export class Nc19Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
