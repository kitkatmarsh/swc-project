import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc19PageRoutingModule } from './nc19-routing.module';

import { Nc19Page } from './nc19.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc19PageRoutingModule
  ],
  declarations: [Nc19Page]
})
export class Nc19PageModule {}
