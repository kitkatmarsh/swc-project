import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc111PageRoutingModule } from './nc111-routing.module';

import { Nc111Page } from './nc111.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc111PageRoutingModule
  ],
  declarations: [Nc111Page]
})
export class Nc111PageModule {}
