import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Nc111Page } from './nc111.page';

const routes: Routes = [
  {
    path: '',
    component: Nc111Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Nc111PageRoutingModule {}
