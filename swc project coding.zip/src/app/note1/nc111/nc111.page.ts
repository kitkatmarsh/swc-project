import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc111',
  templateUrl: './nc111.page.html',
  styleUrls: ['./nc111.page.scss'],
})
export class Nc111Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
