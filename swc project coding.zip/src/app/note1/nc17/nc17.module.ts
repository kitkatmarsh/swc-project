import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc17PageRoutingModule } from './nc17-routing.module';

import { Nc17Page } from './nc17.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc17PageRoutingModule
  ],
  declarations: [Nc17Page]
})
export class Nc17PageModule {}
