import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Nc17Page } from './nc17.page';

const routes: Routes = [
  {
    path: '',
    component: Nc17Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Nc17PageRoutingModule {}
