import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc15PageRoutingModule } from './nc15-routing.module';

import { Nc15Page } from './nc15.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc15PageRoutingModule
  ],
  declarations: [Nc15Page]
})
export class Nc15PageModule {}
