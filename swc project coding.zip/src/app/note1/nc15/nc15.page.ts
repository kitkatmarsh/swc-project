import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc15',
  templateUrl: './nc15.page.html',
  styleUrls: ['./nc15.page.scss'],
})
export class Nc15Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
