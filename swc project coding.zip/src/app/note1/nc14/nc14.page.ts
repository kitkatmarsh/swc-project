import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc14',
  templateUrl: './nc14.page.html',
  styleUrls: ['./nc14.page.scss'],
})
export class Nc14Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
