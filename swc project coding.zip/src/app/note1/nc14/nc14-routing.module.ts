import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Nc14Page } from './nc14.page';

const routes: Routes = [
  {
    path: '',
    component: Nc14Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Nc14PageRoutingModule {}
