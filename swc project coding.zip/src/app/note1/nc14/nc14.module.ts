import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc14PageRoutingModule } from './nc14-routing.module';

import { Nc14Page } from './nc14.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc14PageRoutingModule
  ],
  declarations: [Nc14Page]
})
export class Nc14PageModule {}
