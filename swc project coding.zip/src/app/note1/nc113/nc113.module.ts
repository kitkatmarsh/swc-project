import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc113PageRoutingModule } from './nc113-routing.module';

import { Nc113Page } from './nc113.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc113PageRoutingModule
  ],
  declarations: [Nc113Page]
})
export class Nc113PageModule {}
