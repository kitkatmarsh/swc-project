import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc113',
  templateUrl: './nc113.page.html',
  styleUrls: ['./nc113.page.scss'],
})
export class Nc113Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
