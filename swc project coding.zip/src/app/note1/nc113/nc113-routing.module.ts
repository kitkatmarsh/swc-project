import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Nc113Page } from './nc113.page';

const routes: Routes = [
  {
    path: '',
    component: Nc113Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Nc113PageRoutingModule {}
