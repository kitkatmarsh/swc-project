import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc11',
  templateUrl: './nc11.page.html',
  styleUrls: ['./nc11.page.scss'],
})
export class Nc11Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
