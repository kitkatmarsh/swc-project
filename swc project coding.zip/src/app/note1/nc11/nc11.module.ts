import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc11PageRoutingModule } from './nc11-routing.module';

import { Nc11Page } from './nc11.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc11PageRoutingModule
  ],
  declarations: [Nc11Page]
})
export class Nc11PageModule {}
