import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc18PageRoutingModule } from './nc18-routing.module';

import { Nc18Page } from './nc18.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc18PageRoutingModule
  ],
  declarations: [Nc18Page]
})
export class Nc18PageModule {}
