import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc18',
  templateUrl: './nc18.page.html',
  styleUrls: ['./nc18.page.scss'],
})
export class Nc18Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
