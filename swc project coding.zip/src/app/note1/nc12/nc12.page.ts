import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc12',
  templateUrl: './nc12.page.html',
  styleUrls: ['./nc12.page.scss'],
})
export class Nc12Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
