import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Nc12Page } from './nc12.page';

const routes: Routes = [
  {
    path: '',
    component: Nc12Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Nc12PageRoutingModule {}
