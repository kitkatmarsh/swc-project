import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc12PageRoutingModule } from './nc12-routing.module';

import { Nc12Page } from './nc12.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc12PageRoutingModule
  ],
  declarations: [Nc12Page]
})
export class Nc12PageModule {}
