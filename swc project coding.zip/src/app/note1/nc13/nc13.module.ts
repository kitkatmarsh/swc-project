import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc13PageRoutingModule } from './nc13-routing.module';

import { Nc13Page } from './nc13.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc13PageRoutingModule
  ],
  declarations: [Nc13Page]
})
export class Nc13PageModule {}
