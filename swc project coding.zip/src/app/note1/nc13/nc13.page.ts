import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc13',
  templateUrl: './nc13.page.html',
  styleUrls: ['./nc13.page.scss'],
})
export class Nc13Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
