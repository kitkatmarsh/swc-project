import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc112',
  templateUrl: './nc112.page.html',
  styleUrls: ['./nc112.page.scss'],
})
export class Nc112Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
