import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc112PageRoutingModule } from './nc112-routing.module';

import { Nc112Page } from './nc112.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc112PageRoutingModule
  ],
  declarations: [Nc112Page]
})
export class Nc112PageModule {}
