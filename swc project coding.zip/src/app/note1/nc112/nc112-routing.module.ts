import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Nc112Page } from './nc112.page';

const routes: Routes = [
  {
    path: '',
    component: Nc112Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Nc112PageRoutingModule {}
