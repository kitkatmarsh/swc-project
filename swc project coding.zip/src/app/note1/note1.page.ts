import { Component, OnInit } from '@angular/core';
import { DataService } from "../services/data.service";

@Component({
  selector: 'app-note1',
  templateUrl: './note1.page.html',
  styleUrls: ['./note1.page.scss'],
})
export class Note1Page implements OnInit {
  public searchTerm: String =""
  public items: any;
  constructor(
    private ds: DataService
  ) { }

  ngOnInit() {this.filteredItems();
  }

  filteredItems(){
    this.items = this.ds.filterItems(this.searchTerm);
  }

} 





