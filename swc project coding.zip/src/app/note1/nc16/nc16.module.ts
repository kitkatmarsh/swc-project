import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc16PageRoutingModule } from './nc16-routing.module';

import { Nc16Page } from './nc16.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc16PageRoutingModule
  ],
  declarations: [Nc16Page]
})
export class Nc16PageModule {}
