import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc16',
  templateUrl: './nc16.page.html',
  styleUrls: ['./nc16.page.scss'],
})
export class Nc16Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
