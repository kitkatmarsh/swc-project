import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc110PageRoutingModule } from './nc110-routing.module';

import { Nc110Page } from './nc110.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc110PageRoutingModule
  ],
  declarations: [Nc110Page]
})
export class Nc110PageModule {}
