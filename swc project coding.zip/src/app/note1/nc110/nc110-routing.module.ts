import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Nc110Page } from './nc110.page';

const routes: Routes = [
  {
    path: '',
    component: Nc110Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Nc110PageRoutingModule {}
