import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc110',
  templateUrl: './nc110.page.html',
  styleUrls: ['./nc110.page.scss'],
})
export class Nc110Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
