import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Note1PageRoutingModule } from './note1-routing.module';

import { Note1Page } from './note1.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Note1PageRoutingModule
  ],
  declarations: [Note1Page]
})
export class Note1PageModule {}
