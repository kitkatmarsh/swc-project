import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Note1Page } from './note1.page';

const routes: Routes = [
  {
    path: '',
    component: Note1Page
  },
  {
    path: 'nc11',
    loadChildren: () => import('./nc11/nc11.module').then( m => m.Nc11PageModule)
  },
  {
    path: 'nc12',
    loadChildren: () => import('./nc12/nc12.module').then( m => m.Nc12PageModule)
  },
  {
    path: 'nc13',
    loadChildren: () => import('./nc13/nc13.module').then( m => m.Nc13PageModule)
  },
  {
    path: 'nc14',
    loadChildren: () => import('./nc14/nc14.module').then( m => m.Nc14PageModule)
  },
  {
    path: 'nc15',
    loadChildren: () => import('./nc15/nc15.module').then( m => m.Nc15PageModule)
  },
  {
    path: 'nc16',
    loadChildren: () => import('./nc16/nc16.module').then( m => m.Nc16PageModule)
  },
  {
    path: 'nc17',
    loadChildren: () => import('./nc17/nc17.module').then( m => m.Nc17PageModule)
  },
  {
    path: 'nc18',
    loadChildren: () => import('./nc18/nc18.module').then( m => m.Nc18PageModule)
  },
  {
    path: 'nc19',
    loadChildren: () => import('./nc19/nc19.module').then( m => m.Nc19PageModule)
  },
  {
    path: 'nc110',
    loadChildren: () => import('./nc110/nc110.module').then( m => m.Nc110PageModule)
  },
  {
    path: 'nc111',
    loadChildren: () => import('./nc111/nc111.module').then( m => m.Nc111PageModule)
  },
  {
    path: 'nc112',
    loadChildren: () => import('./nc112/nc112.module').then( m => m.Nc112PageModule)
  },
  {
    path: 'nc113',
    loadChildren: () => import('./nc113/nc113.module').then( m => m.Nc113PageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Note1PageRoutingModule {}
