import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc212',
  templateUrl: './nc212.page.html',
  styleUrls: ['./nc212.page.scss'],
})
export class Nc212Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
