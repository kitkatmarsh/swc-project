import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc212PageRoutingModule } from './nc212-routing.module';

import { Nc212Page } from './nc212.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc212PageRoutingModule
  ],
  declarations: [Nc212Page]
})
export class Nc212PageModule {}
