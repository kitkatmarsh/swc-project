import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Nc212Page } from './nc212.page';

const routes: Routes = [
  {
    path: '',
    component: Nc212Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Nc212PageRoutingModule {}
