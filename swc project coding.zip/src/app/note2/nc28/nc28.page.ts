import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc28',
  templateUrl: './nc28.page.html',
  styleUrls: ['./nc28.page.scss'],
})
export class Nc28Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
