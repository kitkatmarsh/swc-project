import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc28PageRoutingModule } from './nc28-routing.module';

import { Nc28Page } from './nc28.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc28PageRoutingModule
  ],
  declarations: [Nc28Page]
})
export class Nc28PageModule {}
