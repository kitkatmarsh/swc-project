import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Note2Page } from './note2.page';

const routes: Routes = [
  {
    path: '',
    component: Note2Page
  },
  {
    path: 'nc21',
    loadChildren: () => import('./nc21/nc21.module').then( m => m.Nc21PageModule)
  },
  {
    path: 'nc22',
    loadChildren: () => import('./nc22/nc22.module').then( m => m.Nc22PageModule)
  },
  {
    path: 'nc23',
    loadChildren: () => import('./nc23/nc23.module').then( m => m.Nc23PageModule)
  },
  {
    path: 'nc24',
    loadChildren: () => import('./nc24/nc24.module').then( m => m.Nc24PageModule)
  },
  {
    path: 'nc25',
    loadChildren: () => import('./nc25/nc25.module').then( m => m.Nc25PageModule)
  },
  {
    path: 'nc26',
    loadChildren: () => import('./nc26/nc26.module').then( m => m.Nc26PageModule)
  },
  {
    path: 'nc27',
    loadChildren: () => import('./nc27/nc27.module').then( m => m.Nc27PageModule)
  },
  {
    path: 'nc28',
    loadChildren: () => import('./nc28/nc28.module').then( m => m.Nc28PageModule)
  },
  {
    path: 'nc29',
    loadChildren: () => import('./nc29/nc29.module').then( m => m.Nc29PageModule)
  },
  {
    path: 'nc210',
    loadChildren: () => import('./nc210/nc210.module').then( m => m.Nc210PageModule)
  },
  {
    path: 'nc211',
    loadChildren: () => import('./nc211/nc211.module').then( m => m.Nc211PageModule)
  },
  {
    path: 'nc212',
    loadChildren: () => import('./nc212/nc212.module').then( m => m.Nc212PageModule)
  },
  {
    path: 'nc213',
    loadChildren: () => import('./nc213/nc213.module').then( m => m.Nc213PageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Note2PageRoutingModule {}
