import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc23PageRoutingModule } from './nc23-routing.module';

import { Nc23Page } from './nc23.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc23PageRoutingModule
  ],
  declarations: [Nc23Page]
})
export class Nc23PageModule {}
