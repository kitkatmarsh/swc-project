import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc23',
  templateUrl: './nc23.page.html',
  styleUrls: ['./nc23.page.scss'],
})
export class Nc23Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
