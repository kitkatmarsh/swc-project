import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Note2PageRoutingModule } from './note2-routing.module';

import { Note2Page } from './note2.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Note2PageRoutingModule
  ],
  declarations: [Note2Page]
})
export class Note2PageModule {}
