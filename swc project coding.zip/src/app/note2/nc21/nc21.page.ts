import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc21',
  templateUrl: './nc21.page.html',
  styleUrls: ['./nc21.page.scss'],
})
export class Nc21Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
