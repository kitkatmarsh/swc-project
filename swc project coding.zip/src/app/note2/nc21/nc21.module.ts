import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc21PageRoutingModule } from './nc21-routing.module';

import { Nc21Page } from './nc21.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc21PageRoutingModule
  ],
  declarations: [Nc21Page]
})
export class Nc21PageModule {}
