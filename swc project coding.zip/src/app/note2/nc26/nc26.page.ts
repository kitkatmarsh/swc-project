import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc26',
  templateUrl: './nc26.page.html',
  styleUrls: ['./nc26.page.scss'],
})
export class Nc26Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
