import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc26PageRoutingModule } from './nc26-routing.module';

import { Nc26Page } from './nc26.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc26PageRoutingModule
  ],
  declarations: [Nc26Page]
})
export class Nc26PageModule {}
