import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Nc213Page } from './nc213.page';

const routes: Routes = [
  {
    path: '',
    component: Nc213Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Nc213PageRoutingModule {}
