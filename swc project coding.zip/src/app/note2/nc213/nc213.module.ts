import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc213PageRoutingModule } from './nc213-routing.module';

import { Nc213Page } from './nc213.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc213PageRoutingModule
  ],
  declarations: [Nc213Page]
})
export class Nc213PageModule {}
