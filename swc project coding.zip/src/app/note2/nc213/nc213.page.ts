import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc213',
  templateUrl: './nc213.page.html',
  styleUrls: ['./nc213.page.scss'],
})
export class Nc213Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
