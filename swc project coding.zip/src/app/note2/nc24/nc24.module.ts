import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc24PageRoutingModule } from './nc24-routing.module';

import { Nc24Page } from './nc24.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc24PageRoutingModule
  ],
  declarations: [Nc24Page]
})
export class Nc24PageModule {}
