import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc24',
  templateUrl: './nc24.page.html',
  styleUrls: ['./nc24.page.scss'],
})
export class Nc24Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
