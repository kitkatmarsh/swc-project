import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc211PageRoutingModule } from './nc211-routing.module';

import { Nc211Page } from './nc211.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc211PageRoutingModule
  ],
  declarations: [Nc211Page]
})
export class Nc211PageModule {}
