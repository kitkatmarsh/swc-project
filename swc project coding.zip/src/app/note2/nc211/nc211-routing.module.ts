import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Nc211Page } from './nc211.page';

const routes: Routes = [
  {
    path: '',
    component: Nc211Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Nc211PageRoutingModule {}
