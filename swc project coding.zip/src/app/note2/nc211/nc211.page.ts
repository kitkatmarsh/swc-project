import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc211',
  templateUrl: './nc211.page.html',
  styleUrls: ['./nc211.page.scss'],
})
export class Nc211Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
