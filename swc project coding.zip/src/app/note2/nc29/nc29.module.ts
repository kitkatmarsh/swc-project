import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc29PageRoutingModule } from './nc29-routing.module';

import { Nc29Page } from './nc29.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc29PageRoutingModule
  ],
  declarations: [Nc29Page]
})
export class Nc29PageModule {}
