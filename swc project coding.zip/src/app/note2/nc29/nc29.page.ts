import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc29',
  templateUrl: './nc29.page.html',
  styleUrls: ['./nc29.page.scss'],
})
export class Nc29Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
