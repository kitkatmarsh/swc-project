import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Nc29Page } from './nc29.page';

const routes: Routes = [
  {
    path: '',
    component: Nc29Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Nc29PageRoutingModule {}
