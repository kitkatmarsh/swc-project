import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc22',
  templateUrl: './nc22.page.html',
  styleUrls: ['./nc22.page.scss'],
})
export class Nc22Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
