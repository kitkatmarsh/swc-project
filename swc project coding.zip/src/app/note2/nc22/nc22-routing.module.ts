import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Nc22Page } from './nc22.page';

const routes: Routes = [
  {
    path: '',
    component: Nc22Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Nc22PageRoutingModule {}
