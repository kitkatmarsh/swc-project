import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc22PageRoutingModule } from './nc22-routing.module';

import { Nc22Page } from './nc22.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc22PageRoutingModule
  ],
  declarations: [Nc22Page]
})
export class Nc22PageModule {}
