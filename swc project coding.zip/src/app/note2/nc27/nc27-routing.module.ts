import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Nc27Page } from './nc27.page';

const routes: Routes = [
  {
    path: '',
    component: Nc27Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Nc27PageRoutingModule {}
