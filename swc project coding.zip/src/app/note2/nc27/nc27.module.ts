import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc27PageRoutingModule } from './nc27-routing.module';

import { Nc27Page } from './nc27.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc27PageRoutingModule
  ],
  declarations: [Nc27Page]
})
export class Nc27PageModule {}
