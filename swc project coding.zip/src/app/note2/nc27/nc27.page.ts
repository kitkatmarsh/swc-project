import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc27',
  templateUrl: './nc27.page.html',
  styleUrls: ['./nc27.page.scss'],
})
export class Nc27Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
