import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc210PageRoutingModule } from './nc210-routing.module';

import { Nc210Page } from './nc210.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc210PageRoutingModule
  ],
  declarations: [Nc210Page]
})
export class Nc210PageModule {}
