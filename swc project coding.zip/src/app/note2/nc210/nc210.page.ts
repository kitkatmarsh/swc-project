import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc210',
  templateUrl: './nc210.page.html',
  styleUrls: ['./nc210.page.scss'],
})
export class Nc210Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
