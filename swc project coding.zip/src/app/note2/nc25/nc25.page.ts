import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc25',
  templateUrl: './nc25.page.html',
  styleUrls: ['./nc25.page.scss'],
})
export class Nc25Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
