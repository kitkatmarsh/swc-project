import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Nc25Page } from './nc25.page';

const routes: Routes = [
  {
    path: '',
    component: Nc25Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Nc25PageRoutingModule {}
