import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc25PageRoutingModule } from './nc25-routing.module';

import { Nc25Page } from './nc25.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc25PageRoutingModule
  ],
  declarations: [Nc25Page]
})
export class Nc25PageModule {}
