import { Component, OnInit } from '@angular/core';
import { Data2Service } from "../services/data2.service";

@Component({
  selector: 'app-note2',
  templateUrl: './note2.page.html',
  styleUrls: ['./note2.page.scss'],
})
export class Note2Page implements OnInit {
  public searchTerm: String =""
  public items: any;
  constructor(
    private ds: Data2Service
  ) { }

  ngOnInit() {this.filteredItems();
  }

  filteredItems(){
    this.items = this.ds.filterItems(this.searchTerm);
  }

} 


