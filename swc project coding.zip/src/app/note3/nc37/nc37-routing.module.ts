import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Nc37Page } from './nc37.page';

const routes: Routes = [
  {
    path: '',
    component: Nc37Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Nc37PageRoutingModule {}
