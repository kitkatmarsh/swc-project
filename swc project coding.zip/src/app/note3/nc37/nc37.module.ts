import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc37PageRoutingModule } from './nc37-routing.module';

import { Nc37Page } from './nc37.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc37PageRoutingModule
  ],
  declarations: [Nc37Page]
})
export class Nc37PageModule {}
