import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc37',
  templateUrl: './nc37.page.html',
  styleUrls: ['./nc37.page.scss'],
})
export class Nc37Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
