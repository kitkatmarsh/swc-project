import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Nc38Page } from './nc38.page';

const routes: Routes = [
  {
    path: '',
    component: Nc38Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Nc38PageRoutingModule {}
