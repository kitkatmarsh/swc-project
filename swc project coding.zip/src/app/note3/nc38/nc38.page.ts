import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc38',
  templateUrl: './nc38.page.html',
  styleUrls: ['./nc38.page.scss'],
})
export class Nc38Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
