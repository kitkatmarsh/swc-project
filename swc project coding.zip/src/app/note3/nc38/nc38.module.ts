import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc38PageRoutingModule } from './nc38-routing.module';

import { Nc38Page } from './nc38.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc38PageRoutingModule
  ],
  declarations: [Nc38Page]
})
export class Nc38PageModule {}
