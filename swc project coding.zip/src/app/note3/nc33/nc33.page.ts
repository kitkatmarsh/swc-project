import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc33',
  templateUrl: './nc33.page.html',
  styleUrls: ['./nc33.page.scss'],
})
export class Nc33Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
