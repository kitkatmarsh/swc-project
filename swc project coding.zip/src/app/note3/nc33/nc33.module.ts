import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc33PageRoutingModule } from './nc33-routing.module';

import { Nc33Page } from './nc33.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc33PageRoutingModule
  ],
  declarations: [Nc33Page]
})
export class Nc33PageModule {}
