import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc32',
  templateUrl: './nc32.page.html',
  styleUrls: ['./nc32.page.scss'],
})
export class Nc32Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
