import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc32PageRoutingModule } from './nc32-routing.module';

import { Nc32Page } from './nc32.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc32PageRoutingModule
  ],
  declarations: [Nc32Page]
})
export class Nc32PageModule {}
