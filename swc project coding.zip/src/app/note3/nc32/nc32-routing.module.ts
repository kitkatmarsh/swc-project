import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Nc32Page } from './nc32.page';

const routes: Routes = [
  {
    path: '',
    component: Nc32Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Nc32PageRoutingModule {}
