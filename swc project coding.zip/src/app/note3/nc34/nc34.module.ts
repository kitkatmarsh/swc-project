import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc34PageRoutingModule } from './nc34-routing.module';

import { Nc34Page } from './nc34.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc34PageRoutingModule
  ],
  declarations: [Nc34Page]
})
export class Nc34PageModule {}
