import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc34',
  templateUrl: './nc34.page.html',
  styleUrls: ['./nc34.page.scss'],
})
export class Nc34Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
