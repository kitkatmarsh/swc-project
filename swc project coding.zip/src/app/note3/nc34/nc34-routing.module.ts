import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Nc34Page } from './nc34.page';

const routes: Routes = [
  {
    path: '',
    component: Nc34Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Nc34PageRoutingModule {}
