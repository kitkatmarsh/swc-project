import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Nc39Page } from './nc39.page';

const routes: Routes = [
  {
    path: '',
    component: Nc39Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Nc39PageRoutingModule {}
