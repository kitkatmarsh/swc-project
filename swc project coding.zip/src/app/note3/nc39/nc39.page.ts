import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc39',
  templateUrl: './nc39.page.html',
  styleUrls: ['./nc39.page.scss'],
})
export class Nc39Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
