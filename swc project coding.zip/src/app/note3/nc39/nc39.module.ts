import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc39PageRoutingModule } from './nc39-routing.module';

import { Nc39Page } from './nc39.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc39PageRoutingModule
  ],
  declarations: [Nc39Page]
})
export class Nc39PageModule {}
