import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc35PageRoutingModule } from './nc35-routing.module';

import { Nc35Page } from './nc35.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc35PageRoutingModule
  ],
  declarations: [Nc35Page]
})
export class Nc35PageModule {}
