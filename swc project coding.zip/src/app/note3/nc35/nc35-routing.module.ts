import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Nc35Page } from './nc35.page';

const routes: Routes = [
  {
    path: '',
    component: Nc35Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Nc35PageRoutingModule {}
