import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc35',
  templateUrl: './nc35.page.html',
  styleUrls: ['./nc35.page.scss'],
})
export class Nc35Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
