import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc36PageRoutingModule } from './nc36-routing.module';

import { Nc36Page } from './nc36.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc36PageRoutingModule
  ],
  declarations: [Nc36Page]
})
export class Nc36PageModule {}
