import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc36',
  templateUrl: './nc36.page.html',
  styleUrls: ['./nc36.page.scss'],
})
export class Nc36Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
