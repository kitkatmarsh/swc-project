import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Note3PageRoutingModule } from './note3-routing.module';

import { Note3Page } from './note3.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Note3PageRoutingModule
  ],
  declarations: [Note3Page]
})
export class Note3PageModule {}
