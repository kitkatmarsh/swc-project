import { Component, OnInit } from '@angular/core';
import { Data3Service } from "../services/data3.service";

@Component({
  selector: 'app-note3',
  templateUrl: './note3.page.html',
  styleUrls: ['./note3.page.scss'],
})
export class Note3Page implements OnInit {
  public searchTerm: String =""
  public items: any;
  constructor(
    private ds: Data3Service
  ) { }

  ngOnInit() {this.filteredItems();
  }

  filteredItems(){
    this.items = this.ds.filterItems(this.searchTerm);
  }

} 


