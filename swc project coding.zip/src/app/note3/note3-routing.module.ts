import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Note3Page } from './note3.page';

const routes: Routes = [
  {
    path: '',
    component: Note3Page
  },
  {
    path: 'nc31',
    loadChildren: () => import('./nc31/nc31.module').then( m => m.Nc31PageModule)
  },
  {
    path: 'nc32',
    loadChildren: () => import('./nc32/nc32.module').then( m => m.Nc32PageModule)
  },
  {
    path: 'nc33',
    loadChildren: () => import('./nc33/nc33.module').then( m => m.Nc33PageModule)
  },
  {
    path: 'nc34',
    loadChildren: () => import('./nc34/nc34.module').then( m => m.Nc34PageModule)
  },
  {
    path: 'nc35',
    loadChildren: () => import('./nc35/nc35.module').then( m => m.Nc35PageModule)
  },
  {
    path: 'nc36',
    loadChildren: () => import('./nc36/nc36.module').then( m => m.Nc36PageModule)
  },
  {
    path: 'nc37',
    loadChildren: () => import('./nc37/nc37.module').then( m => m.Nc37PageModule)
  },
  {
    path: 'nc38',
    loadChildren: () => import('./nc38/nc38.module').then( m => m.Nc38PageModule)
  },
  {
    path: 'nc39',
    loadChildren: () => import('./nc39/nc39.module').then( m => m.Nc39PageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Note3PageRoutingModule {}
