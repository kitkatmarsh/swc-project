import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nc31',
  templateUrl: './nc31.page.html',
  styleUrls: ['./nc31.page.scss'],
})
export class Nc31Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
