import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Nc31PageRoutingModule } from './nc31-routing.module';

import { Nc31Page } from './nc31.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Nc31PageRoutingModule
  ],
  declarations: [Nc31Page]
})
export class Nc31PageModule {}
