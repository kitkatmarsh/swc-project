import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Option2PageRoutingModule } from './option2-routing.module';

import { Option2Page } from './option2.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Option2PageRoutingModule
  ],
  declarations: [Option2Page]
})
export class Option2PageModule {}
