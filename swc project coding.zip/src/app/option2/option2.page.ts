import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-option2',
  templateUrl: './option2.page.html',
  styleUrls: ['./option2.page.scss'],
})
export class Option2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
