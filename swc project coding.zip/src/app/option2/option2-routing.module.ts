import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Option2Page } from './option2.page';

const routes: Routes = [
  {
    path: '',
    component: Option2Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Option2PageRoutingModule {}
