import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class Data3Service {
  public items: any[];
  constructor() {  
    this.items = [
      {title: "BAB 1: NOMBOR BULAT 10000", page: "nc31"},
      {title: "BAB 2: OPERASI ASAS", page: "nc32"},
      {title: "BAB 3: PECAHAN", page: "nc33"},
      {title: "BAB 4: WANG RM10 000", page: "nc34"},
      {title: "BAB 5: MASA DAN WAKTU", page: "nc35"},
      {title: "BAB 6: PENGUKURAN", page: "nc36"},
      {title: "BAB 7: RUANG", page: "nc37"},
      {title: "BAB 8: KOORDINAT", page: "nc38"},
      {title: "BAB 9: PENGURUSAN DATA", page: "nc39"}
    ]
  }
  filterItems(searchTerm) {
    return this.items.filter(item =>{
      return item.title.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
    }); 
  }
}