import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  public items: any[];
  constructor() {  
    this.items = [
      {title: "BAB 1: NOMBOR HINGGA 10", page: "nc11"},
      {title: "BAB 2: TAMBAH DAN TOLAK HINGGA 10", page: "nc12"},
      {title: "BAB 3: NOMBOR HINGGA 20", page: "nc13"},
      {title: "BAB 4: TAMBAH DAN TOLAK HINGGA 20", page: "nc14"},
      {title: "BAB 5: NOMBOR HINGGA 100", page: "nc15"},
      {title: "BAB 6: TAMBAH DAN TOLAK HINGGA 100", page: "nc16"},
      {title: "BAB 7: PECAHAN", page: "nc17"},
      {title: "BAB 8: WANG", page: "nc18"},
      {title: "BAB 9: MASA DAN WAKTU", page: "nc19"},
      {title: "BAB 10: PANJANG", page: "nc110"},
      {title: "BAB 11: BERAT", page: "nc111"},
      {title: "BAB 12: ISI PADU CECAIR", page: "nc112"},
      {title: "BAB 13: BENTUK", page: "nc113"}
    ]
  }
  filterItems(searchTerm) {
    return this.items.filter(item =>{
      return item.title.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
    }); 
  }
}
