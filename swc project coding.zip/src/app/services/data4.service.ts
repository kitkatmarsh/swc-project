import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class Data4Service {
  public items: any[];
  constructor() { 
    this.items = [ 
      {title: "quizzes chapter 1", page: "qc11"},
      {title: "quizzes chapter 2", page: "qc12"},
      {title: "quizzes chapter 3", page: "qc13"},
      {title: "quizzes chapter 4", page: "qc14"},
      {title: "quizzes chapter 5", page: "qc15"},
      {title: "quizzes chapter 6", page: "qc16"}
    ]
  }
  filterItems(searchTerm) {
    return this.items.filter(item =>{
      return item.title.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
    }); 
  }
}