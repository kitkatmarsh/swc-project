import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class Data2Service {
  public items: any[];
  constructor() {  
    this.items = [
      {title: "BAB 1: NOMBOR HINGGA 1000", page: "nc21"},
      {title: "BAB 2: TAMBAH HINGGA 1000", page: "nc22"},
      {title: "BAB 3: TOLAK HINGGA 1000", page: "nc23"},
      {title: "BAB 4: DARAB", page: "nc24"},
      {title: "BAB 5: BAHAGI", page: "nc25"},
      {title: "BAB 6: PECAHAN", page: "nc26"},
      {title: "BAB 7: PERPULUHAN", page: "nc27"},
      {title: "BAB 8: WANG HINGGA 100", page: "nc28"},
      {title: "BAB 9: MASA DAN WAKTU", page: "nc29"},
      {title: "BAB 10: PANJANG", page: "nc210"},
      {title: "BAB 11: JISIM", page: "nc211"},
      {title: "BAB 12: ISIPADU CECAIR", page: "nc212"},
      {title: "BAB 13: BENTUK", page: "nc213"}
    ]
  }
  filterItems(searchTerm) {
    return this.items.filter(item =>{
      return item.title.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
    }); 
  }
}
