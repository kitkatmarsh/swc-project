import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class Data5Service {
  public items: any[];
  constructor() {  
    this.items = [
      {title: "quizzes chapter 1", page: "qc21"},
      {title: "quizzes chapter 2", page: "qc22"},
      {title: "quizzeschapter 3", page: "qc23"},
      {title: "quizzes chapter 4", page: "qc24"},
      {title: "quizzes chapter 5", page: "qc25"},
      {title: "quizzes chapter 6", page: "qc26"}
    ]
  }
  filterItems(searchTerm) {
    return this.items.filter(item =>{
      return item.title.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
    }); 
  }
}