import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class Data6Service {
  public items: any[];
  constructor() {  
    this.items = [
      {title: "quizzes chapter 1", page: "qc31"},
      {title: "quizzes chapter 2", page: "qc32"},
      {title: "quizzes chapter 3", page: "qc33"},
      {title: "quizzes chapter 4", page: "qc34"},
      {title: "quizzes chapter 5", page: "qc35"},
      {title: "quizzes chapter 6", page: "qc36"}
    ]
  }
  filterItems(searchTerm) {
    return this.items.filter(item =>{
      return item.title.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
    }); 
  }
}