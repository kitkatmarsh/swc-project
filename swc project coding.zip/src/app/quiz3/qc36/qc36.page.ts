import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qc36',
  templateUrl: './qc36.page.html',
  styleUrls: ['./qc36.page.scss'],
})
export class Qc36Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
