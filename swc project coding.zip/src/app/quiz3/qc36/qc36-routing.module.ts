import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Qc36Page } from './qc36.page';

const routes: Routes = [
  {
    path: '',
    component: Qc36Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Qc36PageRoutingModule {}
