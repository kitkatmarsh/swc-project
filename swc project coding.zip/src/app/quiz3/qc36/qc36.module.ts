import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Qc36PageRoutingModule } from './qc36-routing.module';

import { Qc36Page } from './qc36.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Qc36PageRoutingModule
  ],
  declarations: [Qc36Page]
})
export class Qc36PageModule {}
