import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qc32',
  templateUrl: './qc32.page.html',
  styleUrls: ['./qc32.page.scss'],
})
export class Qc32Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
