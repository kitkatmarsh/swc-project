import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Qc32PageRoutingModule } from './qc32-routing.module';

import { Qc32Page } from './qc32.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Qc32PageRoutingModule
  ],
  declarations: [Qc32Page]
})
export class Qc32PageModule {}
