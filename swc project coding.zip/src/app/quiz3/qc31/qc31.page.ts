import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qc31',
  templateUrl: './qc31.page.html',
  styleUrls: ['./qc31.page.scss'],
})
export class Qc31Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
