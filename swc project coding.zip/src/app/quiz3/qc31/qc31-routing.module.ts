import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Qc31Page } from './qc31.page';

const routes: Routes = [
  {
    path: '',
    component: Qc31Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Qc31PageRoutingModule {}
