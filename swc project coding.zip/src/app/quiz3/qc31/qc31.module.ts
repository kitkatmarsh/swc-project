import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Qc31PageRoutingModule } from './qc31-routing.module';

import { Qc31Page } from './qc31.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Qc31PageRoutingModule
  ],
  declarations: [Qc31Page]
})
export class Qc31PageModule {}
