import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Qc34Page } from './qc34.page';

const routes: Routes = [
  {
    path: '',
    component: Qc34Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Qc34PageRoutingModule {}
