import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Qc34PageRoutingModule } from './qc34-routing.module';

import { Qc34Page } from './qc34.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Qc34PageRoutingModule
  ],
  declarations: [Qc34Page]
})
export class Qc34PageModule {}
