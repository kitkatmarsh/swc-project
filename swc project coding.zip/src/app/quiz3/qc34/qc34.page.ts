import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qc34',
  templateUrl: './qc34.page.html',
  styleUrls: ['./qc34.page.scss'],
})
export class Qc34Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
