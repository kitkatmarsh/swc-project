import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Quiz3Page } from './quiz3.page';

const routes: Routes = [
  {
    path: '',
    component: Quiz3Page
  },
  {
    path: 'qc31',
    loadChildren: () => import('./qc31/qc31.module').then( m => m.Qc31PageModule)
  },
  {
    path: 'qc32',
    loadChildren: () => import('./qc32/qc32.module').then( m => m.Qc32PageModule)
  },
  {
    path: 'qc33',
    loadChildren: () => import('./qc33/qc33.module').then( m => m.Qc33PageModule)
  },
  {
    path: 'qc34',
    loadChildren: () => import('./qc34/qc34.module').then( m => m.Qc34PageModule)
  },
  {
    path: 'qc35',
    loadChildren: () => import('./qc35/qc35.module').then( m => m.Qc35PageModule)
  },
  {
    path: 'qc36',
    loadChildren: () => import('./qc36/qc36.module').then( m => m.Qc36PageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Quiz3PageRoutingModule {}
