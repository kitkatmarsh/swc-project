import { Component, OnInit } from '@angular/core';
import { Data6Service } from "../services/data6.service";

@Component({
  selector: 'app-quiz3',
  templateUrl: './quiz3.page.html',
  styleUrls: ['./quiz3.page.scss'],
})
export class Quiz3Page implements OnInit {
  public searchTerm: String =""
  public items: any;
  constructor(
    private ds: Data6Service
  ) { }

  ngOnInit() {this.filteredItems();
  }

  filteredItems(){
    this.items = this.ds.filterItems(this.searchTerm);
  }

} 


