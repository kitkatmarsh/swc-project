import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qc35',
  templateUrl: './qc35.page.html',
  styleUrls: ['./qc35.page.scss'],
})
export class Qc35Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
