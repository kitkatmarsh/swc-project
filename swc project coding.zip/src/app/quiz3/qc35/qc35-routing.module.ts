import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Qc35Page } from './qc35.page';

const routes: Routes = [
  {
    path: '',
    component: Qc35Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Qc35PageRoutingModule {}
