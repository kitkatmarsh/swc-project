import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Qc35PageRoutingModule } from './qc35-routing.module';

import { Qc35Page } from './qc35.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Qc35PageRoutingModule
  ],
  declarations: [Qc35Page]
})
export class Qc35PageModule {}
