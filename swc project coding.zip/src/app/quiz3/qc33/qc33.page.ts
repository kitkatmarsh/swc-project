import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qc33',
  templateUrl: './qc33.page.html',
  styleUrls: ['./qc33.page.scss'],
})
export class Qc33Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
