import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Qc11PageRoutingModule } from './qc11-routing.module';

import { Qc11Page } from './qc11.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Qc11PageRoutingModule
  ],
  declarations: [Qc11Page]
})
export class Qc11PageModule {}
