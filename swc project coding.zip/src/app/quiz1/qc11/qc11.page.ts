import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qc11',
  templateUrl: './qc11.page.html',
  styleUrls: ['./qc11.page.scss'],
})
export class Qc11Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
