import { Component, OnInit } from '@angular/core';
import { Data4Service } from "../services/data4.service";

@Component({
  selector: 'app-quiz1',
  templateUrl: './quiz1.page.html',
  styleUrls: ['./quiz1.page.scss'],
})
export class Quiz1Page implements OnInit {
  public searchTerm: String =""
  public items: any;
  constructor(
    private ds: Data4Service
  ) { }

  ngOnInit() {this.filteredItems();
  }

  filteredItems(){
    this.items = this.ds.filterItems(this.searchTerm);
  }

} 


