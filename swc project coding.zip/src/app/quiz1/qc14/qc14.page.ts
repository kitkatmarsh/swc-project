import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qc14',
  templateUrl: './qc14.page.html',
  styleUrls: ['./qc14.page.scss'],
})
export class Qc14Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
