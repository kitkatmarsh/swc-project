import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Qc14PageRoutingModule } from './qc14-routing.module';

import { Qc14Page } from './qc14.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Qc14PageRoutingModule
  ],
  declarations: [Qc14Page]
})
export class Qc14PageModule {}
