import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Qc14Page } from './qc14.page';

const routes: Routes = [
  {
    path: '',
    component: Qc14Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Qc14PageRoutingModule {}
