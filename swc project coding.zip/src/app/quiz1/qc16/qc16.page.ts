import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qc16',
  templateUrl: './qc16.page.html',
  styleUrls: ['./qc16.page.scss'],
})
export class Qc16Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
