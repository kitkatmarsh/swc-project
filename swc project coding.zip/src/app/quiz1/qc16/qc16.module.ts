import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Qc16PageRoutingModule } from './qc16-routing.module';

import { Qc16Page } from './qc16.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Qc16PageRoutingModule
  ],
  declarations: [Qc16Page]
})
export class Qc16PageModule {}
