import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qc15',
  templateUrl: './qc15.page.html',
  styleUrls: ['./qc15.page.scss'],
})
export class Qc15Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
