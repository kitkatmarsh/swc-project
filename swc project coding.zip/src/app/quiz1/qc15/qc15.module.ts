import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Qc15PageRoutingModule } from './qc15-routing.module';

import { Qc15Page } from './qc15.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Qc15PageRoutingModule
  ],
  declarations: [Qc15Page]
})
export class Qc15PageModule {}
