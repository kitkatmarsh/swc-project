import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Quiz1Page } from './quiz1.page';

const routes: Routes = [
  {
    path: '',
    component: Quiz1Page
  },
  {
    path: 'qc11',
    loadChildren: () => import('./qc11/qc11.module').then( m => m.Qc11PageModule)
  },
  {
    path: 'qc12',
    loadChildren: () => import('./qc12/qc12.module').then( m => m.Qc12PageModule)
  },
  {
    path: 'qc13',
    loadChildren: () => import('./qc13/qc13.module').then( m => m.Qc13PageModule)
  },
  {
    path: 'qc14',
    loadChildren: () => import('./qc14/qc14.module').then( m => m.Qc14PageModule)
  },
  {
    path: 'qc15',
    loadChildren: () => import('./qc15/qc15.module').then( m => m.Qc15PageModule)
  },
  {
    path: 'qc16',
    loadChildren: () => import('./qc16/qc16.module').then( m => m.Qc16PageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Quiz1PageRoutingModule {}
