import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qc12',
  templateUrl: './qc12.page.html',
  styleUrls: ['./qc12.page.scss'],
})
export class Qc12Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
