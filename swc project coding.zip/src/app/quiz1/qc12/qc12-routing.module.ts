import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Qc12Page } from './qc12.page';

const routes: Routes = [
  {
    path: '',
    component: Qc12Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Qc12PageRoutingModule {}
