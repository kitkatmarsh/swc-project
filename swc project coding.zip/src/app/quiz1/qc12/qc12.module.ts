import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Qc12PageRoutingModule } from './qc12-routing.module';

import { Qc12Page } from './qc12.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Qc12PageRoutingModule
  ],
  declarations: [Qc12Page]
})
export class Qc12PageModule {}
