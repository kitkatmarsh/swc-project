import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Qc13PageRoutingModule } from './qc13-routing.module';

import { Qc13Page } from './qc13.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Qc13PageRoutingModule
  ],
  declarations: [Qc13Page]
})
export class Qc13PageModule {}
