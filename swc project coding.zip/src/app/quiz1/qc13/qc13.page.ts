import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qc13',
  templateUrl: './qc13.page.html',
  styleUrls: ['./qc13.page.scss'],
})
export class Qc13Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
