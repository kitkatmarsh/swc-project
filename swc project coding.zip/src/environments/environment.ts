// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyCAUNhZfdAfM6bDfac_u7aHdmc82lDHEXo",
    authDomain: "youngmathematician-1caf8.firebaseapp.com",
    projectId: "youngmathematician-1caf8",
    storageBucket: "youngmathematician-1caf8.appspot.com",
    messagingSenderId: "848212395028",
    appId: "1:848212395028:web:9b163b3ed0fa318e3ed301",
    measurementId: "G-Y4X1J910DX"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
